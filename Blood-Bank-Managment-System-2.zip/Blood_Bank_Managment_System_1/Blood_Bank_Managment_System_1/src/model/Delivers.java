/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Azzam
 */
public class Delivers {
    
    int P_ID,H_ID;

    public Delivers(int P_ID, int H_ID) {
        this.P_ID = P_ID;
        this.H_ID = H_ID;
    }

    public int getP_ID() {
        return P_ID;
    }

    public void setP_ID(int P_ID) {
        this.P_ID = P_ID;
    }

    public int getH_ID() {
        return H_ID;
    }

    public void setH_ID(int H_ID) {
        this.H_ID = H_ID;
    }
    
    
    
}
