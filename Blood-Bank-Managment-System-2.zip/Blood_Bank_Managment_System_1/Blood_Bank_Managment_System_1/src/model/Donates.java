/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Azzam
 */
public class Donates {
    
    int B_ID, D_ID;

    public Donates(int B_ID, int D_ID) {
        this.B_ID = B_ID;
        this.D_ID = D_ID;
    }

    public int getB_ID() {
        return B_ID;
    }

    public void setB_ID(int B_ID) {
        this.B_ID = B_ID;
    }

    public int getD_ID() {
        return D_ID;
    }

    public void setD_ID(int D_ID) {
        this.D_ID = D_ID;
    }
    
    
    
}
